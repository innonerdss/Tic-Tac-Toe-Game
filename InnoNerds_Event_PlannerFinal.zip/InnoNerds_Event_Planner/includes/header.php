<?php

require_once __DIR__ . '/../config.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>InnoNerds Event Planner</title>
  <link rel="stylesheet" href="<?= BASE_URL ?>style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


   <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Your custom CSS (Bootstrap ke baad overwrite karega) -->
<link rel="stylesheet" href="<?= BASE_URL ?>style.css">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>
<!-- Bootstrap JS (for navbar, modals, etc.) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<body>
  <!-- Navbar -->
<header>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
      <a class="navbar-brand d-flex align-items-center" href="<?= BASE_URL ?>index.php">
        <img src="<?= ASSETS_URL ?>logo.png" alt="InnoNerds Logo" style="height:50px;" class="me-2">
        <span>Inno<span style="color:#A020F0;" class="text-warning">Nerds</span></span>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>index.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>about.php">About</a></li>
        
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>blogs.php">Blogs</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>contact.php">Contact</a></li>

          <?php if(isset($_SESSION['admin_id'])): ?>
            <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>Admin/admin.php">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>Admin/reports.php">Reports</a></li>
            <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>Admin/messages.php">Messages</a></li>
            <li class="nav-item"><a class="nav-link text-danger" href="<?= BASE_URL ?>Admin/logout.php">Logout</a></li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>
</header>
<main class="container my-4">


