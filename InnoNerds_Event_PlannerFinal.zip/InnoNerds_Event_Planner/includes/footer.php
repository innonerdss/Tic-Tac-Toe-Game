</main>

 <footer class="footer">
  <img src="<?= ASSETS_URL ?>logo.png" alt="InnoNerds Logo">
 
  <p class="tagline">Imagine | Innovate | Inspire | Impact</p>
   <!-- <p>© <?php echo date("Y"); ?> InnoNerds - All Rights Reserved</p> -->
  
    <div class="footer-links">
    <p>📞 Alyan Ali Khan     : +92 333 8702532</p>
    <p>📞Ali Akbar           : +92 301 5380866</p>
     <!-- <p>© <?php echo date("Y"); ?> InnoNerds - All Rights Reserved</p> -->
    <div class="social-icons">
    <a href="https://l.instagram.com/?u=https%3A%2F%2Fchat.whatsapp.com%2FCYuYIKIl7CH8mwDuJkID3c%3Ffbclid%3DPAZXh0bgNhZW0CMTEAAaceCJi_LT7vi5lnMDgs7TI215RJpLH-Y2714fCxMlEq1OBPtl6lEjltIeFS2A_aem_tiE9-eWEOmH-IFlUtZDvig&e=AT28_YlPKFxV_ZbxW3-V58kcScHkaPVkE39NI4JW7jswjXZBXMQa6HmlH5HDZwhmjeIWtoJUTXVRCvc6E8rNzQ4MN7OP_0ujkKSXltOJsQ" target="_blank"><i class="fab fa-whatsapp"></i></a>
    <a href="https://l.instagram.com/?u=https%3A%2F%2Fwww.linkedin.com%2Fcompany%2Finnonerds%2F%3Ffbclid%3DPAZXh0bgNhZW0CMTEAAaeXcT3DYJFKbXfkFBB30ObK3Jef13ImMg4_jdXequry6tl2SBYcoO4YguobdA_aem_MF_DI5aep8eIZZtcbFZzeA&e=AT2WYuEVkrRBkDoEh6m6A8rLFDJWEJK9W2uQT568LIBnPcrN2dGGDCW4frq9S2tUVrFiIni2U5rvyy_bliMTzWhhGwzgH7mcNaDumoXZWQ" target="_blank"><i class="fab fa-linkedin"></i></a>
    <a href="https://www.instagram.com/innonerds_hitec?igsh=MTJ1MGZtOGQxMXZu" target="_blank">  <i class="fab fa-instagram"></i></a>
  </div>
   <p>© <?php echo date("Y"); ?> InnoNerds - All Rights Reserved</p>
  </div>
   
</footer>
<script src="https://kit.fontawesome.com/yourkitid.js" crossorigin="anonymous"></script>

