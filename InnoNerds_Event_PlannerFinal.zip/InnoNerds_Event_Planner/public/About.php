
<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/header.php'; // header for navbar, logo etc.
// Do NOT check $_SESSION['admin_id'] here!
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - Innonerds</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: #0d0d0d;
      color: #fff;
    }

    .hero {
         height: 50vh; /* sirf half screen lega */
  display: flex;
    justify-content: center;
    align-items: center;
      text-align: center;
      padding: 20px;
      background: linear-gradient(135deg, #6a0dad, #3b0066);
      color: #fff;
      flex-direction: column; 
 
    }

    .hero h2 {
      font-size: 1.8em;
      margin: 8px 0;
      color: #fff;
    }
   
    .hero-content {
  max-width: 600px;  /* Width limit */
  margin: 0 auto;    /* Center align */
}

.hero img {
  width: 90px;
  margin-bottom: 10px;
}
    .hero p {
      font-size: 1em;
      color: #fff;
    }

    .section {
      padding: 60px 15%;
    }

    .section h3 {
      color: #9b59b6;
      margin-bottom: 20px;
    }

    .cards {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
      margin: 50px 0;
      justify-content: center;
    }

    .card {
      flex: 1;
      min-width: 200px;
      background:  #ffffff;
      color: #333;
      padding: 20px;
      border-radius: 10px;
      text-align: center;
      transition: 0.3s;
    }

    .card:hover {
      background: #a066b7ff;
       box-shadow: 0 6px 20px rgba(0,0,0,0.2);
      transform: translateY(-8px);
    }

    /* Back button style */
    .back-btn {
      display: inline-block;
      margin: 40px auto;
      padding: 12px 25px;
      background: #9b59b6;
      color: #fff;
      text-decoration: none;
      font-weight: bold;
      border-radius: 5px;
      transition: 0.3s;
    }

    .back-btn:hover {
      background: #732d91;
    }

    .back-container {
      text-align: center;
    }
  </style>
</head>
<body>

  <!-- Hero Section -->
  <section class="hero">
    <div class="hero-content">
    <img src="../assets/logo.png" alt="Innonerds Logo" >
    <h2>Imagine | Innovate | Inspire | Impact</h2>
    <p>A student-driven community for creativity and innovation</p>
    </div>
  </section>

  <!-- About Section -->
  <section class="section">
    <h3>Who We Are</h3>
    <p>
    InnoNerds is a vibrant community of tech enthusiasts, innovators, and visionaries who believe the fusion of technology and creativity drives the most exciting breakthroughs. From coding projects, hackathons, and emerging tech discussions, we foster collaboration, knowledge-sharing, and problem-solving. Whether you’re a seasoned developer, a budding programmer, or simply curious about the digital world, InnoNerds empowers you to explore, innovate, and shape the future. Together, we transform passion into impactful solutions and redefine the limits of innovation.

At InnoNerds, we celebrate curiosity, encourage experimentation, and embrace challenges as opportunities to grow. Our community thrives on teamwork, mentorship, and a shared mission to create technology that truly matters. By connecting like-minded individuals, we build a space where ideas flourish, creativity thrives, and innovation becomes a way of life.

Join us, and be part of a movement where imagination meets execution, and every spark of creativity has the potential to change the world. 🚀
    </p>
  </section>

  <!-- Mission & Vision Section -->
  <section class="section">
    <h3>Our Mission & Vision</h3>
    <div class="cards">
      <div class="card">
        <h4>Mission</h4>
        <p>To build a platform that nurtures innovation, develops leadership, and creates opportunities for the tech community.</p>
      </div>
      <div class="card">
        <h4>Vision</h4>
        <p>To inspire the next generation of innovators who will transform ideas into solutions that shape the future.</p>
      </div>
    </div>
  </section>

  <!-- Activities Section -->
  <section class="section">
    <h3>Our Activities</h3>
    <ul>
      <li> Exciting MS Azure and Cloud Computing Workshops</li>
      <li> Workshop on Cyber Safty</li>
      <li> Free of cost session of C++ Fundamentals and Arduino Applications.</li>
      <li> Organise a “Intra-Departmental Code Battle Season 1”</li>
      <li> Collaboration Between innoNerds(Hitec University) & Comptech Society(UET Taxila) & also collaborate with YOTA (Bahria University)</li>
      <li> Worked on RC Car Project</li>
      <li> Hands-on *Web Development Sessions* designed specifically for beginners</li>
      <li> Successful Session on LinkedIn Optimisation, Resume writing , Client targeting and boosting skills.</li>

    </ul>
  </section>

  <!-- Values Section -->
  <section class="section">
    <h3>Our Core Values</h3>
    <div class="cards">
      <div class="card">💡 Innovation</div>
      <div class="card">🤝 Collaboration</div>
      <div class="card">🌍 Impact</div>
      <div class="card">📚 Continuous Learning</div>
    </div>
  </section>

  <!-- Back Button -->
  <div class="back-container">
    <a href="index.php" class="back-btn">⬅ Back to Home</a>
  </div>

</body>
</html>


<?php require_once("../includes/footer.php"); ?>
