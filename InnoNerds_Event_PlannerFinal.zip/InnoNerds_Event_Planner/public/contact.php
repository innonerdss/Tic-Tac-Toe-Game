<?php include("../includes/header.php"); ?>
<link rel="stylesheet" href="style.css">

<div class="contact-container">
  <h2>Contact Us</h2>
  <p>
    We’d love to hear from you! Whether you have questions, feedback, or ideas to share, 
    feel free to reach out. Fill out the form below, and our team will get back to you as soon as possible.
  </p>

  <form action="../actions/send_message.php" method="POST" class="contact-form">
    <label for="name">Name</label>
    <input type="text" id="name" name="name" required>

    <label for="email">Email *</label>
    <input type="email" id="email" name="email" required>

    <label for="message">Message *</label>
    <textarea id="message" name="message" rows="5" required></textarea>

    <button type="submit" class="btn-send">Send</button>
  </form>
</div>
<style>
    /* Contact Page Styles */
.contact-container {
  max-width: 700px;
  margin: 40px auto;
  padding: 30px;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.contact-container h2 {
  font-size: 28px;
  margin-bottom: 10px;
  color: #222;
}

.contact-container p {
  color: #555;
  margin-bottom: 20px;
  line-height: 1.6;
}

.contact-form label {
  display: block;
  margin-bottom: 6px;
  font-weight: 600;
  color: #333;
}

.contact-form input,
.contact-form textarea {
  width: 100%;
  padding: 12px;
  margin-bottom: 18px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 15px;
}

.contact-form input:focus,
.contact-form textarea:focus {
  outline: none;
  border-color: #ff5c8a;
  box-shadow: 0 0 6px rgba(255,92,138,0.3);
}

.btn-send {
  background:#9b59b6;
  color: #fff;
  padding: 12px 20px;
  border: none;
  border-radius: 6px;
  font-size: 16px;
  cursor: pointer;
  transition: 0.3s ease;
}

.btn-send:hover {
  background: #e14c77;
}
</style>
<?php include("../includes/footer.php"); ?>
