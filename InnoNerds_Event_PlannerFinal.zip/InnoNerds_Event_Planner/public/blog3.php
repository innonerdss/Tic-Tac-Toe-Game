<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sustainability in Tech - Innonerds</title>
  <style>
  /* Blog Page Styles */
.blog-container {
  max-width: 900px;
  margin: 50px auto;
  padding: 30px;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 6px 20px rgba(0,0,0,0.15);
  font-family: 'Poppins', sans-serif;
  line-height: 1.8;
}

.blog-container h1 {
  font-size: 32px;
  color: #4b0082;
  margin-bottom: 20px;
  text-align: center;
}

.blog-container p {
  font-size: 16px;
  color: #333;
  margin-bottom: 18px;
  text-align: justify;
}

.blog-container img {
  width: 100%;
  border-radius: 10px;
  margin: 20px 0;
}

.back-link {
  display: inline-block;
  margin-top: 25px;
  padding: 10px 20px;
  background: linear-gradient(to right, #A020F0, #ff00ff);
  color: #fff;
  border-radius: 25px;
  text-decoration: none;
  transition: all 0.3s ease;
}

.back-link:hover {
  background: linear-gradient(to right, #ff00ff, #A020F0);
  box-shadow: 0 0 10px rgba(160,32,240,0.6);
}
  </style>
</head>
<body>
    <section class="blog-container">
      <h1>🌱 Building a Sustainable Future with Technology</h1>
      <p><b>Date:</b> May 20, 2025</p>

      <p>
        Sustainability has become one of the most pressing global concerns, and the tech industry has a crucial role to play in addressing environmental challenges. From energy-efficient hardware to eco-friendly software solutions, technology is a powerful enabler of a greener future.
      </p>

      <p>
        Cloud computing and data centers, for instance, consume enormous amounts of energy. Companies are now investing in renewable energy sources, carbon-neutral infrastructure, and innovative cooling systems to reduce their environmental footprint. 
      </p>

      <p>
        On the consumer side, smart devices powered by AI and IoT are helping households and businesses monitor energy consumption and reduce waste. Whether it’s optimizing electricity usage or promoting paperless work environments, technology is driving efficiency at every level.
      </p>

      <p>
        Moreover, advances in green technologies such as electric vehicles, smart grids, and sustainable agriculture tools demonstrate how innovation can align with environmental goals. These developments not only reduce carbon emissions but also create economic opportunities and new jobs.
      </p>

      <p>
        While the progress is encouraging, there is still much to be done. Collaboration among governments, businesses, and individuals is essential to ensure that technology is developed and deployed responsibly. Together, we can build a future where progress and sustainability go hand in hand.
      </p>

      <a href="blogs.php" class="back-link">⬅ Back to Blog</a>
    </section>
</body>
</html>
<?php require_once("../includes/footer.php"); ?>
