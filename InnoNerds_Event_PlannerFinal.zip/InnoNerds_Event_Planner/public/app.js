// ============= SEARCH + FILTER =============
document.addEventListener("DOMContentLoaded", function () {
  const searchInput = document.getElementById("searchInput");
  const dateFilter = document.getElementById("dateFilter");
  const cards = document.querySelectorAll(".card");

  function filterEvents() {
    const query = searchInput ? searchInput.value.toLowerCase() : "";
    const filterDate = dateFilter ? dateFilter.value : "";

    cards.forEach(card => {
      const text = card.innerText.toLowerCase();
      const cardDate = card.getAttribute("data-event-date");
      let visible = true;

      if (query && !text.includes(query)) visible = false;
      if (filterDate && cardDate !== filterDate) visible = false;

      card.style.display = visible ? "block" : "none";
      card.style.backgroundColor = (visible && query) ? "#fff3cd" : "white";
    });
  }

  if (searchInput) searchInput.addEventListener("input", filterEvents);
  if (dateFilter) dateFilter.addEventListener("change", filterEvents);
});

// ============= EDIT MODAL FUNCTIONS =============
// Attach to window so HTML onclick can see them

// window.openEditModal = function(id, title, date, venue, coordinator, status) replace karna h nichay fun kai sath {
function openEditModal(id, title, date, venue, coordinator, status) {
  document.getElementById("edit_id").value = id;
  document.getElementById("edit_title").value = title;
  document.getElementById("edit_date").value = date;
  document.getElementById("edit_venue").value = venue;
  document.getElementById("edit_coordinator").value = coordinator;
  document.getElementById("edit_status").value = status;

  document.getElementById("editModal").style.display = "block";
}

// window.closeEditModal = function() replace with fun {
function closeEditModal() {
  document.getElementById("editModal").style.display = "none";
}
