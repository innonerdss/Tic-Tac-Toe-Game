<?php
require_once("../config.php");
require_once("../includes/header.php");

$stmt = $pdo->query("SELECT * FROM events WHERE status='planned' ORDER BY date ASC LIMIT 6");
$upcoming = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Hero Section -->
<section class="hero">
  <video autoplay muted loop>
    <source src="../assets/background.mp4" type="video/mp4">
    Your browser does not support HTML5 video.
  </video>
  <div>
    <h1>Welcome to <span style="color:#A020F0;">InnoNerds</span></h1>
    <p>Imagine | Innovate | Inspire | Impact</p>
    <a href="#events" class="btn">Explore Events</a>
  </div>
</section>

<!-- Events Section -->
<section id="events" class="events">
  <h2>Upcoming Events</h2>
  <div class="event-grid">
     <?php if(count($upcoming) > 0): ?>
      <?php foreach($upcoming as $event): ?>



    <div class="card">
       <h3><?php echo htmlspecialchars($event['title']); ?></h3>
          <p><b>Date:</b> <?php echo htmlspecialchars($event['date']); ?></p>
          <p><b>Venue:</b> <?php echo htmlspecialchars($event['venue']); ?></p>
          <p><b>Coordinator:</b> <?php echo htmlspecialchars($event['coordinator']); ?></p>
        </div>
 <?php endforeach; ?>
    <?php else: ?>
      <p>No upcoming events found.</p>
    <?php endif; ?>
  </div>
</section>
<?php require_once("../includes/footer.php"); ?>
