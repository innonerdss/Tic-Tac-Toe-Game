<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/header.php'; // header for navbar, logo etc.
// Do NOT check $_SESSION['admin_id'] here!
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - Innonerds</title>
  <style>
  .blog-detail .container {
  max-width: 900px;
  margin: 50px auto;
  padding: 30px;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 6px 20px rgba(0,0,0,0.15);
  font-family: 'Poppins', sans-serif;
  line-height: 1.8;
}

.blog-detail h1 {
  font-size: 32px;
  color: #4b0082;
  margin-bottom: 20px;
  text-align: center;
}

.blog-detail p {
  font-size: 16px;
  color: #333;
  margin-bottom: 18px;
  text-align: justify;
}

.blog-detail img {
  width: 100%;
  border-radius: 10px;
  margin: 20px 0;
}

.blog-detail .btn {
  display: inline-block;
  margin-top: 25px;
  padding: 10px 20px;
  background: linear-gradient(to right, #A020F0, #ff00ff);
  color: #fff;
  border-radius: 25px;
  text-decoration: none;
  transition: all 0.3s ease;
}

.blog-detail .btn:hover {
  background: linear-gradient(to right, #ff00ff, #A020F0);
  box-shadow: 0 0 10px rgba(160,32,240,0.6);
}
    
  </style>
</head>
<body>
    <section class="blog-detail">
  <div class="container">
    <h1>🚀 Launching Our First Hackathon</h1>
    <p><b>Date:</b> March 15, 2025</p>

    <p>
      We are thrilled to announce our very first Hackathon! This event is more than just a competition—it is a celebration of creativity, innovation, and teamwork. Over a span of 24 hours, students, developers, and technology enthusiasts will come together to build solutions for real-world challenges. 
    </p>

    <p>
      The event will feature multiple tracks such as Artificial Intelligence, Web Development, Mobile Applications, and Social Impact Projects. Teams will be free to select the category they are most passionate about. Mentorship sessions will be available throughout the event to guide participants and help them refine their projects. 
    </p>

    <p>
      In addition to the competition, there will be keynote talks by industry experts, networking opportunities, and mini-workshops where participants can learn the latest tools and technologies. The goal is not only to win prizes but also to grow, connect, and inspire one another. 
    </p>

    <p>
      Winning teams will receive exciting rewards including cash prizes, internships, and opportunities to pitch their projects to industry leaders. But more importantly, every participant will walk away with valuable experience, new friendships, and an unforgettable memory. 
    </p>

    <p>
      So gather your team, bring your ideas, and get ready to code your way into innovation! Registration will open soon. Stay tuned for updates and official guidelines.
    </p>

    <a href="blogs.php" class="btn">⬅ Back to Blog</a>
  </div>
</section>
</body>
</html>
<?php require_once("../includes/footer.php"); ?>