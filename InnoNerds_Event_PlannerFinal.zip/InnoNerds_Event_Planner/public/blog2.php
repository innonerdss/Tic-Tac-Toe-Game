<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cultural Fest 2025 - InnoNerds Society</title>
  <style>
  /* Blog Page Styles */
.blog-container {
  max-width: 900px;
  margin: 50px auto;
  padding: 30px;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 6px 20px rgba(0,0,0,0.15);
  font-family: 'Poppins', sans-serif;
  line-height: 1.8;
}

.blog-container h1 {
  font-size: 32px;
  color: #4b0082;
  margin-bottom: 20px;
  text-align: center;
}

.blog-container p {
  font-size: 16px;
  color: #333;
  margin-bottom: 18px;
  text-align: justify;
}

.blog-container img {
  width: 100%;
  border-radius: 10px;
  margin: 20px 0;
}

.back-link {
  display: inline-block;
  margin-top: 25px;
  padding: 10px 20px;
  background: linear-gradient(to right, #A020F0, #ff00ff);
  color: #fff;
  border-radius: 25px;
  text-decoration: none;
  transition: all 0.3s ease;
}

.back-link:hover {
  background: linear-gradient(to right, #ff00ff, #A020F0);
  box-shadow: 0 0 10px rgba(160,32,240,0.6);
}
  </style>
</head>
<body>
    <section class="blog-container">
      <h1>🎉 Celebrating Diversity at the InnoNerds Society Cultural Fest 2025</h1>
      <p><b>Date:</b> April 10, 2025</p>

      <p>
        The <b>InnoNerds Society</b> proudly hosted its annual <b>Cultural Fest 2025</b>, a vibrant celebration of traditions, creativity, and unity. Students and guests from diverse backgrounds came together to showcase their cultures through music, dance, art, and food.
      </p>

      <p>
        The day began with a colorful parade organized by the <b>InnoNerds Society</b>, representing different regions and countries. Participants proudly wore traditional outfits, filling the campus with energy, pride, and enthusiasm. The variety of costumes and performances reflected the beauty of diversity and mutual respect.
      </p>

      <p>
        The event featured live performances including folk dances, musical shows, poetry recitals, and theatrical plays. Each performance told a unique story, highlighting values of harmony, resilience, and creativity. Audiences were captivated by the richness of traditions on stage, all brought together under the leadership of <b>InnoNerds Society</b>.
      </p>

      <p>
        Alongside performances, food stalls set up by <b>InnoNerds Society</b> members served traditional cuisines from around the world, giving everyone a chance to taste new flavors and experience cultural hospitality. From spicy dishes to sweet delicacies, the stalls were packed with food lovers eager to try something new.
      </p>

      <p>
        The Cultural Fest concluded with a unity concert, where artists from different backgrounds performed together on one stage. This powerful finale, hosted by the <b>InnoNerds Society</b>, symbolized the spirit of togetherness and proved that despite differences, we are all connected through culture, art, and humanity.
      </p>

      <a href="blogs.php" class="back-link">⬅ Back to Blog</a>
    </section>
</body>
</html>
<?php require_once("../includes/footer.php"); ?>
