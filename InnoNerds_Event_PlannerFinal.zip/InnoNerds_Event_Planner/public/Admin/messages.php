<?php
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/header.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: " . BASE_URL . "Admin/login.php");
    exit;
}

// Fetch messages
$messages = $pdo->query("SELECT * FROM contact_messages ORDER BY created_at DESC")->fetchAll();
?>

<div class="container">
  <h2>Contact Messages</h2>

  <?php if ($messages && count($messages) > 0): ?>
    <table border="1" cellpadding="10" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Message</th>
          <th>Date</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($messages as $msg): ?>
          <tr style="<?= $msg['is_read'] ? 'background:#f9f9f9;' : 'background:#fff8e1;' ?>">
            <td><?= $msg['id'] ?></td>
            <td><?= htmlspecialchars($msg['name']) ?></td>
            <td><?= htmlspecialchars($msg['email']) ?></td>
            <td><?= nl2br(htmlspecialchars($msg['message'])) ?></td>
            <td><?= $msg['created_at'] ?></td>
            <td><?= $msg['is_read'] ? '✅ Read' : '📩 Unread' ?></td>
            <td>
              <!-- Mark as Read -->
              <?php if (!$msg['is_read']): ?>
                <form method="post" action="<?= ROOT_URL ?>actions/mark_read.php" style="display:inline;">
                  <input type="hidden" name="id" value="<?= $msg['id'] ?>">
                  <button class="btn btn-primary">Mark as Read</button>
                </form>
              <?php endif; ?>

              <!-- Delete -->
              <form method="post" action="<?= ROOT_URL ?>actions/delete_message.php" style="display:inline;">
                <input type="hidden" name="id" value="<?= $msg['id'] ?>">
                <button class="btn btn-danger" onclick="return confirm('Delete this message?')">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else: ?>
    <p>No messages found.</p>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
