<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// require_once('../../config.php'); 
// require_once( '../../includes/header.php'); 
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/header.php';

if (!isset($_SESSION['admin_id'])) {
  header("Location: " . BASE_URL . "Admin/login.php");
  // header("Location: login.php");
  exit;
}
$events = $pdo->query("SELECT * FROM events ORDER BY date ASC")->fetchAll();
?> 



  <div class="container">
    <h2>Manage Events</h2>

    <!-- Add Event -->
    <div class="form-card">
      <h3>Add Event</h3>
      <form method="post" action="<?= ROOT_URL ?>actions/add_event.php">
        <input class="input" type="text" name="title" placeholder="Title" required>
        <input class="input" type="date" name="date" required>
        <input class="input" type="text" name="venue" placeholder="Venue" required>
        <input class="input" type="text" name="coordinator" placeholder="Coordinator" required>
        <textarea class="input" name="description" placeholder="Description"></textarea>
        <select class="input" name="status">
          <option value="planned">Planned</option>
          <option value="ongoing">Ongoing</option>
          <option value="completed">Completed</option>
        </select>
        <button class="btn btn-primary" type="submit">Add Event</button>
      </form>
    </div>

   <h2>Existing Events</h2>
  <?php if ($events && count($events) > 0): ?>
    <?php foreach($events as $ev): ?>
      <div class="event-card" data-event-date="<?php echo $ev['date']; ?>">
        <h3><?php echo htmlspecialchars($ev['title']); ?></h3>
        <!-- <b><?php echo htmlspecialchars($ev['title']); ?></b> (<?php echo $ev['status']; ?>)   -->
        <p><b>Date:</b> <?php echo $ev['date']; ?> | 
           <b>Venue:</b> <?php echo htmlspecialchars($ev['venue']); ?></p>
        <p><b>Coordinator:</b> <?php echo htmlspecialchars($ev['coordinator']); ?></p>
        <p><b>Status:</b> <?php echo ucfirst($ev['status']); ?></p>

          <!-- Delete button -->
            <div class="actions">
          <form method="post" action="<?= ROOT_URL ?>actions/delete_event.php" style="display:inline">
            <input type="hidden" name="id" value="<?php echo $ev['id']; ?>">
            <button class="btn btn-danger">Delete</button>
          </form>

          <!-- Edit button triggers modal -->
          <button class="btn btn-primary" 
                  onclick="openEditModal(<?php echo $ev['id']; ?>,
                                        '<?php echo htmlspecialchars($ev['title']); ?>',
                                        '<?php echo $ev['date']; ?>',
                                        '<?php echo htmlspecialchars($ev['venue']); ?>',
                                        '<?php echo htmlspecialchars($ev['coordinator']); ?>',
                                        '<?php echo $ev['status']; ?>')">
            Edit
          </button>
        </div>
      </div>
      <?php endforeach; ?>
  </div>
    <?php else: ?>
      <p>No events available.</p>
    <?php endif; ?>
  </div>

  <!-- Edit Modal -->
   <!-- style="display:none; position:fixed; top:0; left:0; 
       width:100%; height:100%; background:rgba(0,0,0,0.5);"isko class kai baad likhna h  -->
  <div id="editModal" class="modal" >
    <!-- <div style="background:white; max-width:500px; margin:10% auto; padding:20px; border-radius:8px;"> -->
        <div class="modal-content">
      <h3>Edit Event</h3>
      <form method="post" action="<?= ROOT_URL ?>actions/update_event.php">
        <input type="hidden" name="id" id="edit_id">

        <label>Title</label>
        <input class="input" type="text" name="title" id="edit_title" required>

        <label>Date</label>
        <input class="input" type="date" name="date" id="edit_date" required>

        <label>Venue</label>
        <input class="input" type="text" name="venue" id="edit_venue" required>

        <label>Coordinator</label>
        <input class="input" type="text" name="coordinator" id="edit_coordinator" required>

        <label>Status</label>
        <select class="input" name="status" id="edit_status">
          <option value="planned">Planned</option>
          <option value="ongoing">Ongoing</option>
          <option value="completed">Completed</option>
        </select>

        <br>
        <div class="modal-actions">
        <button class="btn btn-primary" type="submit">Update</button>
        <button class="btn danger" type="button" onclick="closeEditModal()">Cancel</button>
        </div>
      </form>
    </div>
  </div>

<script src=" <?= BASE_URL ?>app.js "></script>


<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
 
<!-- </body>
</html> -->


