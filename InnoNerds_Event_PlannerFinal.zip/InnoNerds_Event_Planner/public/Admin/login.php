<?php
require_once("../../config.php");
$error = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username=?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if($admin && password_verify($password, $admin['password'])){
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['username'];
        header("Location: admin.php");
        exit;
    } else {
        $error = "❌ Invalid username or password!";
    }
}
require_once("../../includes/header.php");
?>
<link rel="stylesheet" href="../style.css">
<!-- Login Page Styling -->
<style>
   @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');
.login-page {
  margin: 0;
      font-family: 'Poppins', sans-serif;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: linear-gradient(to right, #1a0033, #4b0082);
}
 .login-box {
  background: rgba(255, 255, 255, 0.15); /* soft white with slight tint */
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  padding: 20px;
  border-radius: 15px;
  border: 1px solid rgba(255,255,255,0.3);
  width: 400px;
  text-align: center;
  color: #fff;
  box-shadow: 0 8px 20px rgba(0,0,0,0.3); /* purple glow */
}
.login-card label {
  display: block;
  text-align: center;   /* Center align labels */
  font-size: 15px;
  margin: 10px 0 5px 0;
  color: #fff;
  font-weight: 500;
}

.login-box:hover {
  transform: translateY(-5px);
  box-shadow: 0 12px 40px rgba(128,0,128,0.6);
}
.login-box img {
  height: 60px;
  margin-bottom: 15px;
}
.login-box h2 {
  margin-bottom: 25px;
  color: #fff;
}
.login-card input[type="text"], 
.login-card input[type="password"] {
  width: 100%;
  padding: 12px;
  margin: 8px 0;
  border-radius: 25px;
  font-size: 14px;
   box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
   background: rgba(255,255,255,0.2);
  border: 1px solid rgba(255,255,255,0.4);
  color: #fff;
}
.login-card input::placeholder {
  color: rgba(255,255,255,0.7);
}
.error-msg {
  background: #ffe6e6;
  color: #d00;
  padding: 10px;
  border-radius: 8px;
  margin-bottom: 15px;
  font-size: 14px;
}
.btn-login {
  background: linear-gradient(to right, #A020F0, #ff00ff);
  color: #fff;
  border: none;
  padding: 12px 25px;
  width: 100%;
  border-radius:25px;
  cursor: pointer;
  font-weight: bold;
  transition: all 0.3s ease;
}
.btn-login:hover {
  background: linear-gradient(to right, #ff00ff, #A020F0);
   box-shadow: 0 0 15px rgba(160,32,240,0.6);
}
</style>

<div class="login-page">
  <div class="login-box">
    <img src="../../assets/logo.png" alt="InnoNerds Logo">  
<main>
<h2>Admin Login</h2>
<?php if($error): ?>
  <div class="error-box"><?php echo $error; ?></div>
<?php endif; ?>

<form method="POST" class="form-box " >

  <div class="mb-3 col-lg-3">   
    <label for="username" class="form-label" >Username</label>         
    <input type="text"  class="form-control" id="username" name="username" required>
  </div> 

  <div class="mb-3 col-lg-3">
    <label for="password" class="form-label">Password</label> 
    <input type="password" class="form-control" id="password" name="password" required>
  </div>

  <button type="submit" class="btn btn-primary ">Login</button>
</form>
  </main>
<?php require_once("../../includes/footer.php"); ?>
