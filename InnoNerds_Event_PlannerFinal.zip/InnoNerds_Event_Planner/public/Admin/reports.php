<?php
require_once("../../config.php");
require_once("../../includes/header.php");

if(!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}
?>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(to right, #1a0033, #4b0082);
    min-height: 100vh;
    margin: 0;
    display: flex;
    flex-direction: column;
  }

  main {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .report-card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(12px);
    border-radius: 20px;
    padding: 40px;
    text-align: center;
    box-shadow: 0 8px 25px rgba(0,0,0,0.3);
    width: 400px;
    color: white;
  }

  .report-card h2 {
    margin-bottom: 20px;
    font-size: 24px;
    color: #fff;
  }

  .btn-export {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    background: linear-gradient(to right, #A020F0, #ff00ff);
    color: #fff;
    border: none;
    padding: 12px 20px;
    border-radius: 30px;
    margin: 10px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
  }

  .btn-export:hover {
    transform: scale(1.05);
    background: linear-gradient(to right, #ff00ff, #A020F0);
    box-shadow: 0 0 12px rgba(160,32,240,0.6);
  }
</style>
<!-- <div class="container"> -->
  <main>
    <div class="report-card">
<h2>📑 Download Reports</h2>



<!-- CSV -->
<a href="../../actions/export_report_csv.php" target="_blank">
  <button class="btn btn-primary" type="button">📊 Export as CSV</button>
</a>
<!-- PDF -->
<a href="../../actions/export_pdf.php" target="_blank">
  <button class="btn btn-primary" type="button">📄 Export as PDF</button>
</a>
</div>
  </main>



<?php require_once("../../includes/footer.php"); ?>
<!-- <main>
  <div class="report-card">
   
    <a href="export_csv.php" class="btn-export">📊 Export as CSV</a>
    <a href="export_pdf.php" class="btn-export">📄 Export as PDF</a>
  </div>
</main> -->
