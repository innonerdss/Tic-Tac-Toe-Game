
<?php

// echo "BLOG PAGE LOADED!";
// exit;

require_once __DIR__ . '/../config.php';              // config.php root me hai
require_once __DIR__ . '/../includes/header.php';    // header.php includes me hai
?>


<!-- Blog Section -->
<section class="blog-section py-5">
  <div class="container text-center">
    <h1 class="mb-3">Our Blog</h1>
    <p class="text-muted">Read the latest updates, tips, and insights from InnoNerds 🚀</p>

    <div class="row">

      <!-- Blog 1 -->
      <div class="col-md-4">
        <div class="card shadow-sm mb-4">
          <div class="card-body">
            <h5 class="card-title">🚀 Launching Our First Hackathon</h5>
            <p><b>Date:</b> March 15, 2025</p>
            <p>We are excited to announce our first Hackathon where students and tech enthusiasts will come together to build innovative solutions in just 24 hours.</p>
            <a href="<?= BASE_URL ?>blog1.php" class="btn btn-primary btn-sm">Read More</a>
          </div>
        </div>
      </div>

      <!-- Blog 2 -->
      <div class="col-md-4">
        <div class="card shadow-sm mb-4">
          <div class="card-body">
            <h5 class="card-title">🎉 InnoNerds Society Cultural Fest 2025</h5>
            <p><b>Date:</b> April 10, 2025</p>
            <p>The InnoNerds Society proudly hosted its annual Cultural Fest 2025, celebrating diversity, creativity, and unity with music, dance, food, and performances.</p>
            <a href="<?= BASE_URL ?>blog2.php" class="btn btn-primary btn-sm">Read More</a>
          </div>
        </div>
      </div>

      <!-- Blog 3 -->
      <div class="col-md-4">
        <div class="card shadow-sm mb-4">
          <div class="card-body">
            <h5 class="card-title">🌍 Community Meetup Highlights</h5>
            <p><b>Date:</b> May 10, 2025</p>
            <p>Our latest community meetup brought together innovators from different fields. Here’s a quick recap of the best moments and key takeaways.</p>
            <a href="<?= BASE_URL ?>blog3.php" class="btn btn-primary btn-sm">Read More</a>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
