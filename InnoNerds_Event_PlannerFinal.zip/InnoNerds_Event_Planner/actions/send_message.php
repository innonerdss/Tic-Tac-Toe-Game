<?php
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    if (!$name || !$email || !$message) {
        die("All fields are required.");
    }

    $stmt = $pdo->prepare("INSERT INTO contact_messages (name, email, message) VALUES (:name, :email, :message)");
    $stmt->execute([
        ':name' => $name,
        ':email' => $email,
        ':message' => $message
    ]);

    echo "<script>alert('✅ Thank you! Your message has been sent.'); window.location.href='../public/contact.php';</script>";
} else {
    header("Location: ../public/contact.php");
    exit;
}
