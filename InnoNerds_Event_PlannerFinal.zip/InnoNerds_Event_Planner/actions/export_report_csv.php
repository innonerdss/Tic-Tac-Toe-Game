<?php
require_once("../config.php");
if(!isset($_SESSION['admin_id'])) die("Unauthorized");

header("Content-Type: text/csv");
header("Content-Disposition: attachment; filename=event_report.csv");

$output = fopen("php://output", "w");
fputcsv($output, ["Title", "Date", "Venue", "Coordinator", "Status"]);

$stmt = $pdo->query("SELECT title, date, venue, coordinator, status FROM events ORDER BY date ASC");
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
  fputcsv($output, $row);
}
fclose($output);
exit;
