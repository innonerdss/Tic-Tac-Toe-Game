<?php
require_once __DIR__ . '/../config.php';
// if(!isset($_SESSION['admin_id'])) die("Unauthorized");
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];

    if (!$id) {
        die("Event ID is required.");}

$id = $_POST['id'];
$stmt = $pdo->prepare("DELETE FROM events WHERE id= :id");
$stmt->execute([':id' => $id]);

 header("Location: " . BASE_URL . "Admin/admin.php");
exit;
} else {
    die("Invalid request method.");
}