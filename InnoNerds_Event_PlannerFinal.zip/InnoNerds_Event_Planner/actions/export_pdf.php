<?php
require_once("../config.php");
require_once("../lib/fpdf.php");  // FPDF include

if(!isset($_SESSION['admin_id'])) {
    die("Unauthorized");
}

// Fetch events
$stmt = $pdo->query("SELECT title, date, venue, coordinator, status FROM events ORDER BY date ASC");
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Agar data hi nahi hai
if(empty($events)) {
    die("⚠️ No events found to export!");
}

// Create PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);

// Title
$pdf->Cell(0,10,"Events Report",0,1,'C');
$pdf->Ln(5);

// Table Header
$pdf->SetFont('Arial','B',12);
$pdf->Cell(40,10,"Title",1);
$pdf->Cell(30,10,"Date",1);
$pdf->Cell(40,10,"Venue",1);
$pdf->Cell(40,10,"Coordinator",1);
$pdf->Cell(30,10,"Status",1);
$pdf->Ln();

// Table Data
$pdf->SetFont('Arial','',10);
foreach($events as $row) {
    $pdf->Cell(40,10,$row['title'],1);
    $pdf->Cell(30,10,$row['date'],1);
    $pdf->Cell(40,10,$row['venue'],1);
    $pdf->Cell(40,10,$row['coordinator'],1);
    $pdf->Cell(30,10,$row['status'],1);
    $pdf->Ln();
}

// ✅ Output PDF in browser (inline)
$pdf->Output("I", "event_report.pdf");
exit;

