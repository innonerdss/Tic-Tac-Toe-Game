<?php

// var_dump($_SERVER['REQUEST_METHOD']);
// var_dump($_POST);
// die();

require_once __DIR__ . '/../config.php';
// try{
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Use null coalescing operator to avoid undefined index
        $title       = trim($_POST['title'] );
        $date        = $_POST['date'] ;
        $venue       = trim($_POST['venue'] );
        $coordinator = trim($_POST['coordinator']);
        $description = $_POST['description'] ?? '';
        $status      = $_POST['status'] ?? 'planned';
    // Simple validation
    if (!$title || !$date || !$venue || !$coordinator) {
        die("All fields except description are required.");
    }

    // Insert into database
    $stmt = $pdo->prepare("INSERT INTO events (title, date, venue, coordinator, description, status)
                           VALUES (:title, :date, :venue, :coordinator, :description, :status)");
    $stmt->execute([
        ':title'       => $title,
        ':date'        => $date,
        ':venue'       => $venue,
        ':coordinator' => $coordinator,
        ':description' => $description,
        ':status'      => $status
    ]);

    // Redirect back to dashboard
    header("Location: " . BASE_URL . "Admin/admin.php");
    exit;
} else {
    die("Invalid request method.");
}

// } catch (PDOException $e) {
//     die("DB Error: " . $e->getMessage());
// }
