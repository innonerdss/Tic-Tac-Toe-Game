<?php
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id          = $_POST['id'] ;
    $title       = trim($_POST['title']) ;
    $date        = $_POST['date'] ;
    $venue       = trim($_POST['venue']);
    $coordinator = trim($_POST['coordinator']) ;
    $description = $_POST['description'] ?? '';
    $status      = $_POST['status'] ?? 'planned';

    if (!$id || !$title || !$date || !$venue || !$coordinator) {
        die("All fields except description are required.");
    }

    $stmt = $pdo->prepare("UPDATE events 
                           SET title=:title, date=:date, venue=:venue, coordinator=:coordinator, description=:description, status=:status 
                           WHERE id=:id");
    $stmt->execute([
        ':id'          => $id,
        ':title'       => $title,
        ':date'        => $date,
        ':venue'       => $venue,
        ':coordinator' => $coordinator,
        ':description' => $description,
        ':status'      => $status
    ]);

    header("Location: " . BASE_URL . "Admin/admin.php");
    exit;

} else {
    die("Invalid request method.");
}
